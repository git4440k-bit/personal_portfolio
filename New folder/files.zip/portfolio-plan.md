# Kareem Mahmoud — Personal Portfolio (Project Plan)

A single-page personal portfolio website to present Kareem as a **Front-end Developer**.
This file is the agreed plan: use it as the brief when building the project.

---

## 1. Goal & Audience

- **Goal:** get front-end developer jobs / freelance work.
- **Audience:** recruiters and tech leads first, freelance clients second.
- The site itself is the first proof of skill: UI quality, responsiveness and performance matter.

## 2. Tech Stack (decided)

| Area | Choice |
| --- | --- |
| Build tool | **Vite** |
| Library | **React** (plain JavaScript, no TypeScript at first) |
| Styling | **Plain CSS** (or CSS Modules) with CSS variables; no UI libraries (no Bootstrap / Tailwind) |
| Hosting | **Vercel** (free tier), connected to the GitHub repo |
| Language | **English only** (first version) |
| Icons | **react-icons** for the Skills icons **[Proposed]** |

```bash
npm create vite@latest portfolio -- --template react
cd portfolio
npm install
npm run dev
```

## 3. Site Structure (decided)

Single page with a floating glass dock navbar, then the sections in this order (Experience position is **[Proposed]**):

1. **Hero** (Home)
2. **About** (Bento grid)
3. **Experience** (timeline, hidden until Kareem provides entries)
4. **Skills**
5. **Projects**
6. **Contact**

Plus a full-screen **360 degree star background** behind everything.

Not in the first version: blog, multiple pages, CV download button, LinkedIn link.

## 4. Visual Design (decided)

- **Reference site:** https://portfolio-sweandrew.vercel.app/ — same look and colors, plus **yellow** added.
- **Light and dark mode** with a toggle in the navbar. Dark is the main look; **light mode uses a slightly yellowish (warm cream) white instead of pure white**. **[Decided]**
- A **static glow** (radial gradients) spread across the background in both themes, with an **animated 360 degree star canvas** on top of it (see Spec update).
- **Scroll animations** like the reference site (sections and items fade/slide in as they enter the screen). **[Decided]**
- Fully **responsive** (mobile first).

### Color palettes (dark sampled from the reference screenshot; text colors re-measured from the full screenshot)

```css
/* Dark (main look) */
:root,
:root[data-theme="dark"] {
  --bg:          #08080c;  /* page background */
  --surface:     #0b0d11;  /* navbar, cards */
  --glow:        #0f1818;  /* background glow tint */
  --text:        #edeff4;  /* headings */
  --muted:       #8b92a1;  /* secondary text: subtitle, paragraph */
  --soft:        #dbdde1;  /* stat values, secondary button text */
  --nav-link:    #858994;  /* navbar links */
  --dim:         #4b4e56;  /* small mono labels, clock, social links */
  --border:      #1b1d23;  /* pill and badge borders */
  --accent:      #5dead5;  /* teal: primary buttons, links */
  --on-accent:   #08080c;  /* text on teal buttons */
  --yellow:      #facc15;  /* yellow: markers, underlines */
  --yellow-text: #facc15;  /* yellow used as text */
  --radar:       #10b981;  /* live status dot and radar pulse */
  --star-blue:   #7dd3fc;  /* star colors: hex values are proposed, names come from the spec */
  --star-gold:   #fbbf24;
  --star-pink:   #f9a8d4;
  --star-white:  #f8fafc;
  --yellow-glow:      rgba(250, 204, 21, 0.35);  /* glow color for shadows and halos */
  --yellow-glow-soft: rgba(250, 204, 21, 0.12);  /* large soft halos, borders, tints */
}

/* Light (white tinted slightly yellow) */
:root[data-theme="light"] {
  --bg:          #fbf7e9;  /* warm, slightly yellowish white */
  --surface:     #fffdf5;
  --glow:        #f4edc9;
  --text:        #1b1c22;
  --muted:       #5c5f6a;
  --soft:        #2a2c33;  /* proposed */
  --nav-link:    #4a4d58;  /* proposed */
  --dim:         #8a8d98;  /* proposed */
  --border:      #e4dcb8;  /* proposed */
  --accent:      #0f766e;  /* deeper teal so it stays readable on light */
  --on-accent:   #ffffff;
  --yellow:      #facc15;  /* used as highlight background / underline */
  --yellow-text: #a16207;  /* darker yellow when used as text */
  --yellow-glow:      rgba(202, 138, 4, 0.22);  /* subtler glow on the cream background */
  --yellow-glow-soft: rgba(202, 138, 4, 0.10);
}
```
The light values are a starting point and should be checked with a contrast tool (target 4.5:1 for text).

Color roles: teal for primary buttons and links; glowing yellow for emphasis and decoration (see the Glowing Yellow System in the Spec update).

### Typography & text styles (measured from the reference screenshot, 1920px wide)

Sizes were measured in pixels from the screenshot (cap heights, line pitch and character widths), so they are very close but not guaranteed to be byte-exact. Fonts cannot be read from an image: the families below are the **closest Google Fonts match [Proposed]**; if you find the real font names in the reference site's DevTools, swap them in `--font-*` only.

**Font families [Proposed]**

| Role | Look in the screenshot | Closest match |
| --- | --- | --- |
| Display / headings | Bold, tight grotesk sans, very tight letter-spacing | **Inter Tight** (700) |
| Body / subtitle | Neutral humanist sans | **Inter** (400 / 500 / 600) |
| Labels, nav, buttons | Monospace, small, often UPPERCASE with wide tracking | **JetBrains Mono** (400 / 700) |

```css
:root {
  --font-display: "Inter Tight", "Inter", system-ui, sans-serif;
  --font-body:    "Inter", system-ui, sans-serif;
  --font-mono:    "JetBrains Mono", ui-monospace, "SFMono-Regular", Menlo, monospace;
}
```

**Text styles (desktop, 1920px). Colors use the tokens above.**

| Element | Font | Size / line-height | Weight | Case / tracking | Color |
| --- | --- | --- | --- | --- | --- |
| Hero name (2 lines) | display | **112px** / **105px** (about 0.94) | 700 | normal, letter-spacing about -0.04em | `--text` `#edeff4` |
| Hero subtitle ("Senior ... Engineer") | body | **32px** / 1.2 | 500 | normal | `--muted` `#8b92a1` |
| Subtitle key word ("Full-Stack") | body | 32px | 600 | normal, 2px underline below it | `--text` `#edeff5`, underline in accent (teal in the reference, **yellow** for Kareem) |
| Label line ("BUILDS //") | mono | **14px** | 400 | UPPERCASE, 0.05em | `--dim` `#484c56` |
| Label line highlight ("BOT DEVELOPMENT") | mono | 14px | 700 | UPPERCASE, 0.05em | teal `#7ad6c9` |
| Hero paragraph | body | **18px** / **29px** (1.6) | 400 | normal | `--muted` (about `#8b92a1`) |
| Primary button text | mono | **13px** | 700 | normal, 0.05em | `--on-accent` on `--accent` fill, pill 191 x 42px |
| Secondary button text ("View work") | mono | 13px | 700 | normal | `#d9dbdf` on transparent, 1px border `--border`, pill |
| Social links ("GITHUB LINKEDIN") | mono | **11px** | 400 | UPPERCASE, 0.1em | `--dim` `#4d5059` |
| Navbar logo (`Kareem`, plain text) | mono | **14px** | 700 | as written, 0 | `#e2e4ea` (the reference's 12px uppercase brand is replaced) |
| Navbar links | mono | **13.5px or more** (spec) | 400 | normal, about 0.02em | `--nav-link` `#858994` |
| Navbar button ("Connect") | mono | 13.5px | 700 | normal | `#e1e3e7`, pill with 1px border |
| Status badge ("OPEN TO ...") | mono | **11px** | 400 | UPPERCASE, 0.1em | `#777b84`, teal dot, pill 221 x 32px, 1px border |
| Location / clock | mono | 11px | 400 | UPPERCASE, 0.2em | `--dim` `#4b4f57` |
| Stat label ("BASE", "STACK") | mono | **10px** | 400 | UPPERCASE, 0.05em | `--dim` `#4b4e56` |
| Stat value ("10+ yrs", stack list) | mono | **14px** | 500 | normal | `--soft` `#dbdde1` / `#e2e4e8` |
| Scroll hint ("SCROLL") | mono | **10px** | 400 | UPPERCASE, 0.2em | `#51545c` |

**Layout measurements from the same screenshot:** the content column starts at x = 408px (a centered container of about 1100px); the navbar is a floating pill about 760px wide and 64px tall with a 1px border; the glow is centered on the right half of the hero.

**Responsive sizes [Proposed]** (so the 112px name does not break on phones):

```css
:root {
  --fs-hero:     clamp(3.5rem, 8vw, 7rem);      /* 56px to 112px */
  --fs-subtitle: clamp(1.5rem, 3vw, 2rem);      /* 24px to 32px  */
  --fs-body:     clamp(1rem, 1.2vw, 1.125rem);  /* 16px to 18px  */
  --fs-mono-lg:  0.875rem;  /* 14px: label line, stat values */
  --fs-mono:     0.8125rem; /* 13px: buttons */
  --fs-mono-sm:  0.75rem;   /* 12px: navbar */
  --fs-mono-xs:  0.6875rem; /* 11px: badge, social links, clock */
  --fs-mono-2xs: 0.625rem;  /* 10px: stat labels, scroll hint */
}
```

Adaptation for Kareem: the pattern stays the same (huge two-line name, subtitle with one key word emphasized, mono label line, gray paragraph, two pill buttons, small stat row), but the underline under "Front-end" is **yellow**. Light mode uses the same sizes and weights with the light tokens.

### Theme behavior

- Default theme follows the device setting (`prefers-color-scheme`); the visitor's choice is saved in `localStorage`.
- The theme is applied with a `data-theme` attribute on `<html>`; a tiny inline script in `index.html` sets it before the first paint so the page never flashes the wrong theme.
- The toggle is a button in the navbar (sun/moon icon, with an `aria-label`).
- The static glow exists in both themes (in light mode it is a soft warm tint).

### Animation

- **Scroll reveal:** each section and its items fade and slide up slightly when they enter the screen (`IntersectionObserver`, triggered once).
- **Stagger:** items inside a group (skills, project cards) appear one after another with a small delay.
- **Hover:** subtle lift and glow on skill items, cards and buttons; the active nav link is highlighted while scrolling.
- Built with CSS transitions and a small `useReveal` hook; no animation library.
- All motion is turned off when the visitor has `prefers-reduced-motion` enabled; this includes the star canvas drift and the navbar's pulse (see Spec update).
- The reference site's exact animation could not be inspected from text, so this is the standard scroll-reveal approach, to be adjusted after Kareem reviews it.

### Spec update (Kareem, 2026-10-29)

This block records the latest design spec. Where it conflicts with earlier text, **this block wins**; every conflict is listed in the table at the end. Items marked **[Proposed]** are my fill-ins for details the spec did not give.

#### Floating Glass Dock Navbar
- A floating, fully rounded **dock** centered at the top: `border-radius: 9999px`, `backdrop-filter: blur(20px)` over a semi-transparent glass background (`--surface`) with a 1px `--border`.
- **Glass on scroll:** once the page scrolls down, the dock turns into clear glass with `backdrop-filter: blur(28px) saturate(200%)` and a more transparent background, so the stars and page content stay visible as they move underneath. Add `-webkit-backdrop-filter` too, and a more opaque fallback where `backdrop-filter` is unsupported. **[Proposed]** trigger: `scrollY > 8` in a small scroll listener.
- **Logo and identity:** the word `Kareem` in plain text (no `<`, `/` or `>` brackets) with a **live status dot**: green `#10b981` with a "radar pulse" (an expanding, fading ring animation).
- **Links (font-size 13.5px or more):** Home, About, Experience, Projects, Contact, plus a **Connect** button (scrolls to Contact) and the theme toggle. Skills is also linked **[Proposed]**, because the Skills section stays.
- On mobile the dock collapses into a menu button.

#### Hero (details in section 5, Content)
Live availability badge, gradient headline, tech chips, two CTAs and small stat cards.

#### About as a Bento Grid
- The plain paragraph becomes a grid of **glass cards with a 3D feel** (subtle perspective tilt on hover, layered shadow, inner highlight border).
- Cards **[Proposed]**: Bio (the approved About text), Focus, Background (information systems, computer networks, accounting, public economics), Location (Egypt), Links (GitHub and email). Only facts Kareem already gave are used.
- Desktop: asymmetric multi-column grid; mobile: single column. Tilt is disabled on touch screens and with `prefers-reduced-motion`.

#### Experience Timeline (new)
- New component `src/components/Experience.jsx`, styles in `src/styles/Experience.css`, wired into `src/App.jsx`; data in `src/data/experience.js` **[Proposed]**.
- **Interactive vertical timeline:** a glowing gradient line connects the stops; each stop is a glowing circular node that reacts when the pointer is over it.
- **Experience cards:** job title, organization, period badge, a list of achievements and tasks with `▹` bullets, and technology tags for each stage.
- Data shape: `{ title, org, period, points: [], tech: [] }`.
- **Content comes from Kareem** (internships, freelance work, academic projects). No invented entries ship. If none are ready at launch, the section and its nav link are hidden, the same rule as Projects (Option A).

#### 360 degree Star Background (new)
- `src/components/StarBackground.jsx`: a full-screen fixed canvas behind the content with `pointer-events: none`.
- **3D feel:** a projection with `perspective: 1100px`; moving the mouse rotates the star dome, eased with smooth **damping**.
- **Ambient drift:** a slow, constant rotation of the dome, even when the mouse is still.
- **300+ stars** spread over depth layers, in four colors (sky blue, solar gold, cosmic pink, diamond white) plus occasional shooting stars.
- Safeguards **[Proposed]**: draw loop paused when the tab is hidden; fewer stars (about 120) on small screens; device pixel ratio capped at 2; drift and mouse rotation off under `prefers-reduced-motion` (stars are drawn static). Plain Canvas 2D, no 3D library.
- Light mode **[Proposed, to confirm]:** soft dark-tinted dots at low opacity (or hidden); the warm static glow stays underneath.

#### Glowing Yellow System (update, 2026-10-29)

**Rule:** teal means *action* (buttons, links); glowing yellow means *emphasis and life*. Yellow glow is used at a few planned focal points, never everywhere: no more than 2 or 3 glowing yellow elements are visible in one screen, and they all share one glow recipe so the page feels coordinated.

```css
:root {
  --glow-yellow:      0 0 12px var(--yellow-glow), 0 0 32px var(--yellow-glow-soft); /* box-shadow */
  --glow-yellow-text: 0 0 14px var(--yellow-glow);                                   /* text-shadow */
}
```

| Place | Glowing yellow treatment |
| --- | --- |
| Hero | "Front-end" underline is a 2px yellow line with the glow; one large, soft yellow halo (radial gradient, opacity 0.12 or less) sits behind the headline on the left, balanced by a teal halo on the right. The availability dot stays green (status), not yellow |
| Dock navbar | Active link gets a small glowing yellow dot or underline; the Connect button gets a yellow glow ring on hover; after scrolling, a 1px yellow-tinted highlight runs along the dock's top edge |
| Section headings | A short glowing yellow dash above each section title |
| Bento and stat cards | On hover the border turns yellow-soft with the glow; the Bio card has a yellow glowing corner gradient as the one featured card |
| Experience timeline | The vertical line is a teal-to-yellow gradient with a glow; nodes are glowing yellow circles that intensify on hover; period badges use a yellow-soft background |
| Skills | The small yellow markers glow on hover |
| Background | Very soft yellow halos (opacity 0.12 or less) behind the Experience and Contact sections, inside the existing static glow |
| Stars | Gold stars get a small soft halo; the glow stays subtle |
| Focus states | Keyboard focus ring is yellow with the glow (visible in both themes) |

Rules:
- **Contrast:** yellow text is only used for large or emphasized text on dark (`--yellow-text` `#facc15`); on the cream light theme use `#a16207` and a weaker glow. Glow is decoration only: a state or meaning is never carried by the glow alone.
- **Performance:** glows are `box-shadow`, `text-shadow` and radial gradients; transitions animate opacity and `box-shadow` only (never blur radius), and the only looping animations are the green radar dot and the star canvas. All glow transitions are off under `prefers-reduced-motion`.

#### Conflicts with earlier decisions, and how they were resolved
| Earlier decision | Now |
| --- | --- |
| Static glow only, no animated particles | Animated star canvas on top of the glow (spec wins) |
| Navbar links 12px (measured from the reference) | 13.5px or more (spec wins); all other measurements stay |
| Big two-line name as the Hero heading | "Building scalable web experiences" is the H1; the name moves to an identity line and the navbar logo |
| Agreed skills: HTML5, CSS3, JavaScript, React, Git/GitHub, Responsive Design, Vite | Hero chips also list TypeScript, Node.js and REST APIs: **needs Kareem's confirmation** before launch |
| Text styles "exactly like the screenshot" | Sizes, weights and fonts still follow the screenshot table; the headline fill is a gradient built from palette tokens |
| Particles listed as "not in the first version" | Moved into scope as the star canvas |
| Yellow only as small markers and underlines | Glowing yellow system at planned focal points (see above) |
| Logo written `<Kareem />` | Plain `Kareem` |

---

## 5. Content

### Hero
- **Badge:** live radar dot (green `#10b981`, pulsing) + "Available for new opportunities • Software & Web"
- **Headline (H1):** "Building scalable web experiences", bold, with a bright gradient text fill **[Proposed colors: teal to yellow, from the palette]**
- **Identity line** under the headline: "Kareem Mahmoud · Front-end Developer", with "Front-end" emphasized and underlined in yellow **[Proposed arrangement, keeps the earlier decision]**
- **Tech chips** (small pills): React, JavaScript, TypeScript, Node.js, REST APIs, Modern CSS **[Needs confirmation: TypeScript, Node.js and REST APIs are not in the agreed skills list, so keep only what Kareem actually knows; the chips come from the data file]**
- **Buttons:** `Explore Projects ↗` (primary, teal) and `Get in Touch` (secondary)
- **Stat cards:** small glass cards for Focus, Experience, Location and GitHub. Values: Focus = front-end / React; Location = Egypt; GitHub = profile link; Experience = **[to be provided by Kareem, no number invented]**

> The old tagline "I build clean, responsive web interfaces with React." is no longer in the Hero; it can move to the About Bento.

### About (approved)

> I'm a front-end developer and recent graduate with a background in information systems, computer networks, and business subjects like accounting and public economics. I enjoy turning ideas into fast, responsive interfaces with React, and I like building tools that make sense for real users and real businesses.

### Skills (decided)

Layout: grouped like the **Experience** section of the reference site, but **each skill has an icon** and the whole block is neatly organized:

- Each group has a heading, and below it a tidy list/grid of skill items.
- Each item shows: **icon + name + one-line note**.
- Items reveal with a staggered animation and have a subtle hover effect.
- No percentage bars.

Groups:

- **Languages:** HTML5, CSS3, JavaScript (ES6+)
- **Frameworks & Libraries:** React
- **Tools & Practices:** Git/GitHub, Responsive Design, Vite

Icons **[Proposed]**: `react-icons` (for example `SiHtml5`, `SiCss3`, `SiJavascript`, `SiReact`, `SiGit`, `SiGithub`, `SiVite`, and a generic devices icon for Responsive Design).

Each skill gets a one-line note about how it was used (to be written by Kareem).

### Projects (decided)

- 3 project cards, **added after the portfolio is finished**.
- Each card: **live demo link + GitHub link + short description** (the problem it solves and the technologies used).
- Projects live in a separate data file so adding one never touches the components:

```js
// src/data/projects.js
export const projects = [
  {
    title: "Project name",
    description: "What problem it solves, in two lines.",
    tech: ["React", "CSS"],
    demo: "https://...",
    github: "https://github.com/...",
  },
];
```

### Contact (decided)

- **Email** (opens mail client via `mailto:`)
- **GitHub**
- No LinkedIn yet (to be added later as a single line in the data/config), no CV button for now.

## 6. Suggested Folder Structure

```
portfolio/
├─ public/
├─ src/
│  ├─ components/
│  │  ├─ Navbar.jsx
│  │  ├─ ThemeToggle.jsx
│  │  ├─ Hero.jsx
│  │  ├─ About.jsx
│  │  ├─ Experience.jsx
│  │  ├─ Skills.jsx
│  │  ├─ Projects.jsx
│  │  ├─ Contact.jsx
│  │  └─ StarBackground.jsx
│  ├─ data/
│  │  ├─ experience.js
│  │  ├─ projects.js
│  │  └─ skills.js
│  ├─ hooks/
│  │  ├─ useTheme.js
│  │  └─ useReveal.js
│  ├─ styles/
│  │  ├─ variables.css
│  │  ├─ global.css
│  │  └─ Experience.css
│  ├─ App.jsx
│  └─ main.jsx
└─ index.html   (includes the small theme script)
```

## 7. Deployment (Vercel)

1. Push the project to a GitHub repository.
2. On Vercel: **Add New → Project**, import the repo (Vite is auto-detected).
3. Deploy. Every `git push` updates the site automatically.
4. Optional later: buy a custom domain and connect it.

## 8. Next Steps

1. Build the project with the structure above.
2. Confirm which tech chips are true (React, JavaScript, TypeScript, Node.js, REST APIs, Modern CSS).
3. Write the one-line notes for each skill.
4. Send the real Experience entries (title, organization, period, achievements, technologies), or decide to hide that section for now.
5. Create a LinkedIn profile, then add its link to Contact.
6. Add the 3 projects to `projects.js`.
7. Prepare an English CV and add the download button when ready.
