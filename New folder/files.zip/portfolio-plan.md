# Kareem Mahmoud — Personal Portfolio (Project Plan)

A single-page personal portfolio website to present Kareem as a **Front-end Developer**.
This file is the agreed plan: use it as the brief when building the project.

---

## 1. Goal & Audience

- **Goal:** get front-end developer jobs / freelance work.
- **Audience:** recruiters and tech leads first, freelance clients second.
- The site itself is the first proof of skill: UI quality, responsiveness and performance matter.

## 2. Tech Stack (decided)

| Area | Choice |
| --- | --- |
| Build tool | **Vite** |
| Library | **React** (plain JavaScript, no TypeScript at first) |
| Styling | **Plain CSS** (or CSS Modules) with CSS variables; no UI libraries (no Bootstrap / Tailwind) |
| Hosting | **Vercel** (free tier), connected to the GitHub repo |
| Language | **English only** (first version) |
| Icons | **react-icons** for the Skills icons **[Proposed]** |

```bash
npm create vite@latest portfolio -- --template react
cd portfolio
npm install
npm run dev
```

## 3. Site Structure (decided)

Single page, sections in this order:

1. **Hero**
2. **About**
3. **Skills**
4. **Projects**
5. **Contact**

Not in the first version: blog, multiple pages, particle backgrounds, CV download button, LinkedIn link.

## 4. Visual Design (decided)

- **Reference site:** https://portfolio-sweandrew.vercel.app/ — same look and colors, plus **yellow** added.
- **Light and dark mode** with a toggle in the navbar. Dark is the main look; **light mode uses a slightly yellowish (warm cream) white instead of pure white**. **[Decided]**
- A **static glow** (radial gradients) spread across the background of the whole site in both themes. No animated particles.
- **Scroll animations** like the reference site (sections and items fade/slide in as they enter the screen). **[Decided]**
- Fully **responsive** (mobile first).

### Color palettes (dark sampled from the reference screenshot; text colors re-measured from the full screenshot)

```css
/* Dark (main look) */
:root,
:root[data-theme="dark"] {
  --bg:          #08080c;  /* page background */
  --surface:     #0b0d11;  /* navbar, cards */
  --glow:        #0f1818;  /* background glow tint */
  --text:        #edeff4;  /* headings */
  --muted:       #8b92a1;  /* secondary text: subtitle, paragraph */
  --soft:        #dbdde1;  /* stat values, secondary button text */
  --nav-link:    #858994;  /* navbar links */
  --dim:         #4b4e56;  /* small mono labels, clock, social links */
  --border:      #1b1d23;  /* pill and badge borders */
  --accent:      #5dead5;  /* teal: primary buttons, links */
  --on-accent:   #08080c;  /* text on teal buttons */
  --yellow:      #facc15;  /* yellow: markers, underlines */
  --yellow-text: #facc15;  /* yellow used as text */
}

/* Light (white tinted slightly yellow) */
:root[data-theme="light"] {
  --bg:          #fbf7e9;  /* warm, slightly yellowish white */
  --surface:     #fffdf5;
  --glow:        #f4edc9;
  --text:        #1b1c22;
  --muted:       #5c5f6a;
  --soft:        #2a2c33;  /* proposed */
  --nav-link:    #4a4d58;  /* proposed */
  --dim:         #8a8d98;  /* proposed */
  --border:      #e4dcb8;  /* proposed */
  --accent:      #0f766e;  /* deeper teal so it stays readable on light */
  --on-accent:   #ffffff;
  --yellow:      #facc15;  /* used as highlight background / underline */
  --yellow-text: #a16207;  /* darker yellow when used as text */
}
```
The light values are a starting point and should be checked with a contrast tool (target 4.5:1 for text).

Suggested roles (not yet confirmed): teal for primary buttons and links; yellow for highlights (key word in the title, hover states, small markers in Skills).

### Typography & text styles (measured from the reference screenshot, 1920px wide)

Sizes were measured in pixels from the screenshot (cap heights, line pitch and character widths), so they are very close but not guaranteed to be byte-exact. Fonts cannot be read from an image: the families below are the **closest Google Fonts match [Proposed]**; if you find the real font names in the reference site's DevTools, swap them in `--font-*` only.

**Font families [Proposed]**

| Role | Look in the screenshot | Closest match |
| --- | --- | --- |
| Display / headings | Bold, tight grotesk sans, very tight letter-spacing | **Inter Tight** (700) |
| Body / subtitle | Neutral humanist sans | **Inter** (400 / 500 / 600) |
| Labels, nav, buttons | Monospace, small, often UPPERCASE with wide tracking | **JetBrains Mono** (400 / 700) |

```css
:root {
  --font-display: "Inter Tight", "Inter", system-ui, sans-serif;
  --font-body:    "Inter", system-ui, sans-serif;
  --font-mono:    "JetBrains Mono", ui-monospace, "SFMono-Regular", Menlo, monospace;
}
```

**Text styles (desktop, 1920px). Colors use the tokens above.**

| Element | Font | Size / line-height | Weight | Case / tracking | Color |
| --- | --- | --- | --- | --- | --- |
| Hero name (2 lines) | display | **112px** / **105px** (about 0.94) | 700 | normal, letter-spacing about -0.04em | `--text` `#edeff4` |
| Hero subtitle ("Senior ... Engineer") | body | **32px** / 1.2 | 500 | normal | `--muted` `#8b92a1` |
| Subtitle key word ("Full-Stack") | body | 32px | 600 | normal, 2px underline below it | `--text` `#edeff5`, underline in accent (teal in the reference, **yellow** for Kareem) |
| Label line ("BUILDS //") | mono | **14px** | 400 | UPPERCASE, 0.05em | `--dim` `#484c56` |
| Label line highlight ("BOT DEVELOPMENT") | mono | 14px | 700 | UPPERCASE, 0.05em | teal `#7ad6c9` |
| Hero paragraph | body | **18px** / **29px** (1.6) | 400 | normal | `--muted` (about `#8b92a1`) |
| Primary button text | mono | **13px** | 700 | normal, 0.05em | `--on-accent` on `--accent` fill, pill 191 x 42px |
| Secondary button text ("View work") | mono | 13px | 700 | normal | `#d9dbdf` on transparent, 1px border `--border`, pill |
| Social links ("GITHUB LINKEDIN") | mono | **11px** | 400 | UPPERCASE, 0.1em | `--dim` `#4d5059` |
| Navbar brand | mono | **12px** | 700 | UPPERCASE, 0.1em | `#e2e4ea` |
| Navbar links | mono | **12px** | 400 | normal, about 0.02em | `--nav-link` `#858994` |
| Navbar button ("Get in touch") | mono | 12px | 700 | normal | `#e1e3e7`, pill with 1px border |
| Status badge ("OPEN TO ...") | mono | **11px** | 400 | UPPERCASE, 0.1em | `#777b84`, teal dot, pill 221 x 32px, 1px border |
| Location / clock | mono | 11px | 400 | UPPERCASE, 0.2em | `--dim` `#4b4f57` |
| Stat label ("BASE", "STACK") | mono | **10px** | 400 | UPPERCASE, 0.05em | `--dim` `#4b4e56` |
| Stat value ("10+ yrs", stack list) | mono | **14px** | 500 | normal | `--soft` `#dbdde1` / `#e2e4e8` |
| Scroll hint ("SCROLL") | mono | **10px** | 400 | UPPERCASE, 0.2em | `#51545c` |

**Layout measurements from the same screenshot:** the content column starts at x = 408px (a centered container of about 1100px); the navbar is a floating pill about 760px wide and 64px tall with a 1px border; the glow is centered on the right half of the hero.

**Responsive sizes [Proposed]** (so the 112px name does not break on phones):

```css
:root {
  --fs-hero:     clamp(3.5rem, 8vw, 7rem);      /* 56px to 112px */
  --fs-subtitle: clamp(1.5rem, 3vw, 2rem);      /* 24px to 32px  */
  --fs-body:     clamp(1rem, 1.2vw, 1.125rem);  /* 16px to 18px  */
  --fs-mono-lg:  0.875rem;  /* 14px: label line, stat values */
  --fs-mono:     0.8125rem; /* 13px: buttons */
  --fs-mono-sm:  0.75rem;   /* 12px: navbar */
  --fs-mono-xs:  0.6875rem; /* 11px: badge, social links, clock */
  --fs-mono-2xs: 0.625rem;  /* 10px: stat labels, scroll hint */
}
```

Adaptation for Kareem: the pattern stays the same (huge two-line name, subtitle with one key word emphasized, mono label line, gray paragraph, two pill buttons, small stat row), but the underline under "Front-end" is **yellow**. Light mode uses the same sizes and weights with the light tokens.

### Theme behavior

- Default theme follows the device setting (`prefers-color-scheme`); the visitor's choice is saved in `localStorage`.
- The theme is applied with a `data-theme` attribute on `<html>`; a tiny inline script in `index.html` sets it before the first paint so the page never flashes the wrong theme.
- The toggle is a button in the navbar (sun/moon icon, with an `aria-label`).
- The static glow exists in both themes (in light mode it is a soft warm tint).

### Animation

- **Scroll reveal:** each section and its items fade and slide up slightly when they enter the screen (`IntersectionObserver`, triggered once).
- **Stagger:** items inside a group (skills, project cards) appear one after another with a small delay.
- **Hover:** subtle lift and glow on skill items, cards and buttons; the active nav link is highlighted while scrolling.
- Built with CSS transitions and a small `useReveal` hook; no animation library.
- All motion is turned off when the visitor has `prefers-reduced-motion` enabled.
- The reference site's exact animation could not be inspected from text, so this is the standard scroll-reveal approach, to be adjusted after Kareem reviews it.

---

## 5. Content

### Hero
- **Name:** Kareem Mahmoud
- **Title:** Front-end Developer (the words "Front-end" highlighted in yellow)
- **Tagline:** "I build clean, responsive web interfaces with React."
- **Buttons:** View projects (teal) / Contact me
- **Badge:** "Open to work" + location (Egypt)

> Hero details beyond the name are suggested defaults, change them freely.

### About (approved)

> I'm a front-end developer and recent graduate with a background in information systems, computer networks, and business subjects like accounting and public economics. I enjoy turning ideas into fast, responsive interfaces with React, and I like building tools that make sense for real users and real businesses.

### Skills (decided)

Layout: grouped like the **Experience** section of the reference site, but **each skill has an icon** and the whole block is neatly organized:

- Each group has a heading, and below it a tidy list/grid of skill items.
- Each item shows: **icon + name + one-line note**.
- Items reveal with a staggered animation and have a subtle hover effect.
- No percentage bars.

Groups:

- **Languages:** HTML5, CSS3, JavaScript (ES6+)
- **Frameworks & Libraries:** React
- **Tools & Practices:** Git/GitHub, Responsive Design, Vite

Icons **[Proposed]**: `react-icons` (for example `SiHtml5`, `SiCss3`, `SiJavascript`, `SiReact`, `SiGit`, `SiGithub`, `SiVite`, and a generic devices icon for Responsive Design).

Each skill gets a one-line note about how it was used (to be written by Kareem).

### Projects (decided)

- 3 project cards, **added after the portfolio is finished**.
- Each card: **live demo link + GitHub link + short description** (the problem it solves and the technologies used).
- Projects live in a separate data file so adding one never touches the components:

```js
// src/data/projects.js
export const projects = [
  {
    title: "Project name",
    description: "What problem it solves, in two lines.",
    tech: ["React", "CSS"],
    demo: "https://...",
    github: "https://github.com/...",
  },
];
```

### Contact (decided)

- **Email** (opens mail client via `mailto:`)
- **GitHub**
- No LinkedIn yet (to be added later as a single line in the data/config), no CV button for now.

## 6. Suggested Folder Structure

```
portfolio/
├─ public/
├─ src/
│  ├─ components/
│  │  ├─ Navbar.jsx
│  │  ├─ ThemeToggle.jsx
│  │  ├─ Hero.jsx
│  │  ├─ About.jsx
│  │  ├─ Skills.jsx
│  │  ├─ Projects.jsx
│  │  └─ Contact.jsx
│  ├─ data/
│  │  ├─ projects.js
│  │  └─ skills.js
│  ├─ hooks/
│  │  ├─ useTheme.js
│  │  └─ useReveal.js
│  ├─ styles/
│  │  ├─ variables.css
│  │  └─ global.css
│  ├─ App.jsx
│  └─ main.jsx
└─ index.html   (includes the small theme script)
```

## 7. Deployment (Vercel)

1. Push the project to a GitHub repository.
2. On Vercel: **Add New → Project**, import the repo (Vite is auto-detected).
3. Deploy. Every `git push` updates the site automatically.
4. Optional later: buy a custom domain and connect it.

## 8. Next Steps

1. Build the project with the structure above.
2. Write the one-line notes for each skill.
3. Create a LinkedIn profile, then add its link to Contact.
4. Add the 3 projects to `projects.js`.
5. Prepare an English CV and add the download button when ready.
