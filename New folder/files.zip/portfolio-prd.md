# PRD — Kareem Mahmoud Personal Portfolio

| | |
| --- | --- |
| **Product** | Personal portfolio website |
| **Owner** | Kareem Mahmoud |
| **Version** | 1.3 (first release, updated with the glass dock navbar, new Hero, Bento About, Experience timeline and star background spec) |
| **Status** | Draft, ready for build |
| **Date** | 2026-10-29 |

> Items marked **[Decided]** were confirmed by Kareem. Items marked **[Proposed]** are suggested defaults that can be changed.

---

## 1. Overview

A single-page personal portfolio that presents Kareem Mahmoud as a **Front-end Developer**. The site is both the showcase and the first proof of skill: its design quality, responsiveness and performance are part of the pitch.

## 2. Problem & Goals

**Problem:** Kareem has no public place that presents his skills and projects to recruiters and clients in a clear, professional way.

**Goals**
1. Give recruiters and tech leads a fast understanding of who Kareem is, what he builds, and how to reach him. **[Decided]**
2. Demonstrate front-end ability through the site itself (React, CSS, responsive layout). **[Decided]**
3. Make adding new projects trivial (data-driven, no component changes). **[Decided]**

**Non-goals (version 1)** **[Decided]**
- Blog, multiple pages, or a CMS
- Heavy animation or 3D libraries (the star canvas uses plain Canvas 2D)
- CV download button
- LinkedIn link (no account yet)
- Multi-language support (English only)

## 3. Target Users

| User | Need | What they look for |
| --- | --- | --- |
| Recruiter / hiring manager | Judge a candidate in about 30 seconds | Name, role, skills, best projects, a way to contact |
| Tech lead / interviewer | Assess technical quality | Live demos, GitHub code, clean UI, responsive behavior |
| Freelance client | Find someone who can build an interface | Past work and an easy contact route |

## 4. User Stories

- As a recruiter, I want to see the name and role immediately so I know who this is without scrolling.
- As a recruiter, I want a short, honest summary so I can understand the background quickly.
- As a tech lead, I want to see the skills grouped clearly so I can match them to our stack.
- As a tech lead, I want each project to have a live demo and a GitHub link so I can verify the work.
- As any visitor on a phone, I want the site to be fully usable on a small screen.
- As any visitor, I want one obvious way to contact Kareem.

## 5. Functional Requirements

### 5.1 Navigation
- **FR-1** A floating glass dock navbar (see 5.11) with the logo `Kareem` and a live status dot, links to Home, About, Experience, Projects, Contact (and Skills **[Proposed]**), a **Connect** button, and a light/dark theme toggle. **[Decided]**
- **FR-2** Clicking a link scrolls smoothly to the matching section.
- **FR-3** On mobile the navbar collapses into a menu. **[Proposed]**

### 5.2 Hero **[Decided structure, Proposed wording]**
- **FR-4** Headline (H1): "Building scalable web experiences" with a bold gradient fill, and an identity line "Kareem Mahmoud · Front-end Developer" with "Front-end" emphasized in yellow **[Proposed arrangement]**.
- **FR-5** A row of tech chips: React, JavaScript, TypeScript, Node.js, REST APIs, Modern CSS, rendered from the skills data. **[Needs confirmation of TypeScript, Node.js and REST APIs]**
- **FR-6** Two buttons: **Explore Projects ↗** (primary, teal) scrolls to Projects; **Get in Touch** scrolls to Contact.
- **FR-7** A live availability badge: a pulsing green radar dot and the text "Available for new opportunities • Software & Web".
- **FR-7b** Small glass stat cards for Focus, Experience, Location and GitHub. The Experience value is supplied by Kareem; none is invented.

### 5.3 About **[Decided]**
- **FR-8** Shows this text (inside the Bento grid, see 5.12):

> I'm a front-end developer and recent graduate with a background in information systems, computer networks, and business subjects like accounting and public economics. I enjoy turning ideas into fast, responsive interfaces with React, and I like building tools that make sense for real users and real businesses.

### 5.4 Skills **[Decided]**
- **FR-9** Skills are grouped like the Experience section of the reference site, in a neat, well-organized layout: each group has a heading and a tidy list/grid of items.
- **FR-10** Three groups:
  - Languages: HTML5, CSS3, JavaScript (ES6+)
  - Frameworks & Libraries: React
  - Tools & Practices: Git/GitHub, Responsive Design, Vite
- **FR-11** Each item shows an **icon, the skill name and a one-line note**.
- **FR-12** No percentage bars or fake proficiency levels.
- **FR-13** Skills come from `src/data/skills.js`, including the icon reference.
- **FR-14** Items reveal with a staggered scroll animation and have a subtle hover effect.
- Icons **[Proposed]:** `react-icons`.

### 5.5 Projects **[Decided]**
- **FR-15** Shows 3 project cards, added after the site is finished.
- **FR-16** Each card has: title, short description (problem solved), technology tags, a **live demo** link, and a **GitHub** link.
- **FR-17** Cards are rendered from `src/data/projects.js`; adding a project means adding one object.
- **FR-18** If a project has no demo or no GitHub link, that button is hidden instead of broken.

### 5.6 Contact **[Decided]**
- **FR-19** Shows an **Email** link (`mailto:`) and a **GitHub** link.
- **FR-20** Links open in a new tab (except `mailto:`), with `rel="noopener noreferrer"`.
- **FR-21** Adding LinkedIn later requires adding one entry in a config/data file, with no layout change.

### 5.7 Footer **[Proposed]**
- **FR-22** A small footer with the name and the year.

### 5.8 Light / Dark Theme **[Decided]**
- **FR-23** A toggle in the navbar switches between light and dark mode.
- **FR-24** Light mode uses a **slightly yellowish (warm cream) white** background, not pure white.
- **FR-25** The default follows the device setting; the visitor's choice is saved and restored on the next visit.
- **FR-26** The correct theme is applied before the first paint (no flash of the wrong theme).
- **FR-27** Text and controls meet contrast requirements in both themes.

### 5.9 Animation **[Decided]**
- **FR-28** Sections and their items fade/slide in as they enter the screen (scroll reveal), triggered once.
- **FR-29** Items inside a group appear with a small stagger.
- **FR-30** Subtle hover effects on skill items, cards and buttons; the active nav link is highlighted.
- **FR-31** All motion is disabled when `prefers-reduced-motion` is on.

### 5.10 Typography **[Decided]**
- **FR-32** Text uses the sizes, weights, case, letter-spacing and colors in section 6.1, measured from the reference screenshot.
- **FR-33** Three font roles: display (headings), body, and monospace (nav, labels, buttons); loaded from Google Fonts with `display=swap` and system fallbacks. Exact families are **[Proposed]**.
- The reference site's exact animation could not be inspected from text; the standard scroll-reveal approach is used and adjusted after review.

### 5.11 Floating Glass Dock Navbar **[Decided]**
- **FR-34** The navbar is a floating, fully rounded dock (`border-radius: 9999px`) with `backdrop-filter: blur(20px)` over a glass background and a 1px border.
- **FR-35** On scroll down it becomes clear glass with `backdrop-filter: blur(28px) saturate(200%)`, so stars and content remain visible underneath; a more opaque fallback is used where `backdrop-filter` is unsupported.
- **FR-36** Logo is the plain word `Kareem` (no `<`, `/` or `>`) with a live green dot (`#10b981`) that has a radar-pulse animation.
- **FR-37** Link text is 13.5px or larger; links: Home, About, Experience, Projects, Contact, a **Connect** button and the theme toggle. On mobile the dock collapses into a menu.

### 5.12 About as a Bento Grid **[Decided structure, Proposed card content]**
- **FR-38** The About content is a grid of glass cards with a subtle 3D tilt on hover (disabled on touch and with reduced motion).
- **FR-39** Proposed cards: Bio, Focus, Background, Location, Links. Only facts Kareem provided are used. Single column on mobile.

### 5.13 Experience Timeline **[Decided]**
- **FR-40** New `Experience.jsx` component, styled in `Experience.css`, wired into `App.jsx`, reading from `src/data/experience.js` **[Proposed path]**.
- **FR-41** A vertical timeline with a glowing gradient line and glowing circular nodes that react to hover.
- **FR-42** Each card shows the job title, organization, a period badge, a list of achievements with `▹` bullets, and technology tags. Data shape: `{ title, org, period, points: [], tech: [] }`.
- **FR-43** Entries come from Kareem; if there are none at launch, the section and its nav link are hidden.

### 5.14 360 degree Star Background **[Decided]**
- **FR-44** `StarBackground.jsx` renders a fixed full-screen canvas behind the content (`pointer-events: none`) with `perspective: 1100px` projection.
- **FR-45** Mouse movement rotates the star dome with smooth damping; a slow ambient drift rotates it even when the mouse is still.
- **FR-46** 300 or more stars in depth layers, in sky blue, solar gold, cosmic pink and diamond white, plus occasional shooting stars.
- **FR-47** **[Proposed]** safeguards: pause when the tab is hidden, fewer stars on small screens, device pixel ratio capped at 2, and static stars with `prefers-reduced-motion`.
- **FR-48** **[Proposed, to confirm]** In light mode the stars are soft, dark-tinted and low opacity (or hidden).

### 5.15 Glowing Yellow Accent **[Decided]**
- **FR-49** A coordinated glowing yellow accent appears at planned focal points: the Hero "Front-end" underline and a soft halo behind the headline, the active nav link and Connect hover in the navbar, a short dash above each section title, card hover borders, the Experience line and nodes, and soft halos behind the Experience and Contact sections.
- **FR-50** All yellow glows share one recipe (`--glow-yellow`, `--glow-yellow-text`), built from `--yellow-glow` and `--yellow-glow-soft`.
- **FR-51** No more than 2 or 3 glowing yellow elements are visible in one screen; teal remains the color for actions.
- **FR-52** The keyboard focus ring is yellow with the glow in both themes.
- **FR-53** In light mode the glow is weaker and yellow text uses `#a16207`; the glow never carries meaning on its own.
- **FR-54** Glow transitions animate opacity and `box-shadow` only, and are disabled with `prefers-reduced-motion`.

## 6. Design Requirements **[Decided]**

- **Reference:** https://portfolio-sweandrew.vercel.app/ for layout feel and colors, plus yellow.
- **Themes:** light and dark mode with a navbar toggle. Dark is the main look; light mode uses a slightly yellowish white.
- **Background:** a **static glow** (radial gradients) in both themes, with the animated 360 degree star canvas on top (see 5.14).
- **Responsive:** mobile first; no horizontal scrolling at any width.
- **No UI libraries;** all styling is hand-written CSS with CSS variables (an icon pack is allowed).

```css
/* Dark (main look) */
:root,
:root[data-theme="dark"] {
  --bg:          #08080c;  /* page background */
  --surface:     #0b0d11;  /* navbar, cards */
  --glow:        #0f1818;  /* background glow tint */
  --text:        #edeff4;  /* headings */
  --muted:       #8b92a1;  /* secondary text: subtitle, paragraph */
  --soft:        #dbdde1;  /* stat values, secondary button text */
  --nav-link:    #858994;  /* navbar links */
  --dim:         #4b4e56;  /* small mono labels, clock, social links */
  --border:      #1b1d23;  /* pill and badge borders */
  --accent:      #5dead5;  /* teal: primary buttons, links */
  --on-accent:   #08080c;  /* text on teal buttons */
  --yellow:      #facc15;  /* yellow: markers, underlines */
  --yellow-text: #facc15;  /* yellow used as text */
  --radar:       #10b981;  /* live status dot and radar pulse */
  --star-blue:   #7dd3fc;  /* star colors: hex values are proposed, names come from the spec */
  --star-gold:   #fbbf24;
  --star-pink:   #f9a8d4;
  --star-white:  #f8fafc;
  --yellow-glow:      rgba(250, 204, 21, 0.35);  /* glow color for shadows and halos */
  --yellow-glow-soft: rgba(250, 204, 21, 0.12);  /* large soft halos, borders, tints */
}

/* Light (white tinted slightly yellow) */
:root[data-theme="light"] {
  --bg:          #fbf7e9;  /* warm, slightly yellowish white */
  --surface:     #fffdf5;
  --glow:        #f4edc9;
  --text:        #1b1c22;
  --muted:       #5c5f6a;
  --soft:        #2a2c33;  /* proposed */
  --nav-link:    #4a4d58;  /* proposed */
  --dim:         #8a8d98;  /* proposed */
  --border:      #e4dcb8;  /* proposed */
  --accent:      #0f766e;  /* deeper teal so it stays readable on light */
  --on-accent:   #ffffff;
  --yellow:      #facc15;  /* used as highlight background / underline */
  --yellow-text: #a16207;  /* darker yellow when used as text */
  --yellow-glow:      rgba(202, 138, 4, 0.22);  /* subtler glow on the cream background */
  --yellow-glow-soft: rgba(202, 138, 4, 0.10);
}
```
The light values are a starting point and should be checked with a contrast tool (target 4.5:1 for text).

Color roles: teal for primary buttons and links; glowing yellow for emphasis and decoration (see 5.15 and the Glowing Yellow System in section 6.2).

### 6.1 Typography & text styles (measured from the reference screenshot, 1920px wide)

Sizes were measured in pixels from the screenshot (cap heights, line pitch and character widths), so they are very close but not guaranteed to be byte-exact. Fonts cannot be read from an image: the families below are the **closest Google Fonts match [Proposed]**; if you find the real font names in the reference site's DevTools, swap them in `--font-*` only.

**Font families [Proposed]**

| Role | Look in the screenshot | Closest match |
| --- | --- | --- |
| Display / headings | Bold, tight grotesk sans, very tight letter-spacing | **Inter Tight** (700) |
| Body / subtitle | Neutral humanist sans | **Inter** (400 / 500 / 600) |
| Labels, nav, buttons | Monospace, small, often UPPERCASE with wide tracking | **JetBrains Mono** (400 / 700) |

```css
:root {
  --font-display: "Inter Tight", "Inter", system-ui, sans-serif;
  --font-body:    "Inter", system-ui, sans-serif;
  --font-mono:    "JetBrains Mono", ui-monospace, "SFMono-Regular", Menlo, monospace;
}
```

**Text styles (desktop, 1920px). Colors use the tokens above.**

| Element | Font | Size / line-height | Weight | Case / tracking | Color |
| --- | --- | --- | --- | --- | --- |
| Hero name (2 lines) | display | **112px** / **105px** (about 0.94) | 700 | normal, letter-spacing about -0.04em | `--text` `#edeff4` |
| Hero subtitle ("Senior ... Engineer") | body | **32px** / 1.2 | 500 | normal | `--muted` `#8b92a1` |
| Subtitle key word ("Full-Stack") | body | 32px | 600 | normal, 2px underline below it | `--text` `#edeff5`, underline in accent (teal in the reference, **yellow** for Kareem) |
| Label line ("BUILDS //") | mono | **14px** | 400 | UPPERCASE, 0.05em | `--dim` `#484c56` |
| Label line highlight ("BOT DEVELOPMENT") | mono | 14px | 700 | UPPERCASE, 0.05em | teal `#7ad6c9` |
| Hero paragraph | body | **18px** / **29px** (1.6) | 400 | normal | `--muted` (about `#8b92a1`) |
| Primary button text | mono | **13px** | 700 | normal, 0.05em | `--on-accent` on `--accent` fill, pill 191 x 42px |
| Secondary button text ("View work") | mono | 13px | 700 | normal | `#d9dbdf` on transparent, 1px border `--border`, pill |
| Social links ("GITHUB LINKEDIN") | mono | **11px** | 400 | UPPERCASE, 0.1em | `--dim` `#4d5059` |
| Navbar logo (`Kareem`, plain text) | mono | **14px** | 700 | as written, 0 | `#e2e4ea` (the reference's 12px uppercase brand is replaced) |
| Navbar links | mono | **13.5px or more** (spec) | 400 | normal, about 0.02em | `--nav-link` `#858994` |
| Navbar button ("Connect") | mono | 13.5px | 700 | normal | `#e1e3e7`, pill with 1px border |
| Status badge ("OPEN TO ...") | mono | **11px** | 400 | UPPERCASE, 0.1em | `#777b84`, teal dot, pill 221 x 32px, 1px border |
| Location / clock | mono | 11px | 400 | UPPERCASE, 0.2em | `--dim` `#4b4f57` |
| Stat label ("BASE", "STACK") | mono | **10px** | 400 | UPPERCASE, 0.05em | `--dim` `#4b4e56` |
| Stat value ("10+ yrs", stack list) | mono | **14px** | 500 | normal | `--soft` `#dbdde1` / `#e2e4e8` |
| Scroll hint ("SCROLL") | mono | **10px** | 400 | UPPERCASE, 0.2em | `#51545c` |

**Layout measurements from the same screenshot:** the content column starts at x = 408px (a centered container of about 1100px); the navbar is a floating pill about 760px wide and 64px tall with a 1px border; the glow is centered on the right half of the hero.

**Responsive sizes [Proposed]** (so the 112px name does not break on phones):

```css
:root {
  --fs-hero:     clamp(3.5rem, 8vw, 7rem);      /* 56px to 112px */
  --fs-subtitle: clamp(1.5rem, 3vw, 2rem);      /* 24px to 32px  */
  --fs-body:     clamp(1rem, 1.2vw, 1.125rem);  /* 16px to 18px  */
  --fs-mono-lg:  0.875rem;  /* 14px: label line, stat values */
  --fs-mono:     0.8125rem; /* 13px: buttons */
  --fs-mono-sm:  0.75rem;   /* 12px: navbar */
  --fs-mono-xs:  0.6875rem; /* 11px: badge, social links, clock */
  --fs-mono-2xs: 0.625rem;  /* 10px: stat labels, scroll hint */
}
```

Adaptation for Kareem: the pattern stays the same (huge two-line name, subtitle with one key word emphasized, mono label line, gray paragraph, two pill buttons, small stat row), but the underline under "Front-end" is **yellow**. Light mode uses the same sizes and weights with the light tokens.

### 6.2 Glowing Yellow System

**Rule:** teal means *action* (buttons, links); glowing yellow means *emphasis and life*. Yellow glow is used at a few planned focal points, never everywhere: no more than 2 or 3 glowing yellow elements are visible in one screen, and they all share one glow recipe so the page feels coordinated.

```css
:root {
  --glow-yellow:      0 0 12px var(--yellow-glow), 0 0 32px var(--yellow-glow-soft); /* box-shadow */
  --glow-yellow-text: 0 0 14px var(--yellow-glow);                                   /* text-shadow */
}
```

| Place | Glowing yellow treatment |
| --- | --- |
| Hero | "Front-end" underline is a 2px yellow line with the glow; one large, soft yellow halo (radial gradient, opacity 0.12 or less) sits behind the headline on the left, balanced by a teal halo on the right. The availability dot stays green (status), not yellow |
| Dock navbar | Active link gets a small glowing yellow dot or underline; the Connect button gets a yellow glow ring on hover; after scrolling, a 1px yellow-tinted highlight runs along the dock's top edge |
| Section headings | A short glowing yellow dash above each section title |
| Bento and stat cards | On hover the border turns yellow-soft with the glow; the Bio card has a yellow glowing corner gradient as the one featured card |
| Experience timeline | The vertical line is a teal-to-yellow gradient with a glow; nodes are glowing yellow circles that intensify on hover; period badges use a yellow-soft background |
| Skills | The small yellow markers glow on hover |
| Background | Very soft yellow halos (opacity 0.12 or less) behind the Experience and Contact sections, inside the existing static glow |
| Stars | Gold stars get a small soft halo; the glow stays subtle |
| Focus states | Keyboard focus ring is yellow with the glow (visible in both themes) |

Rules:
- **Contrast:** yellow text is only used for large or emphasized text on dark (`--yellow-text` `#facc15`); on the cream light theme use `#a16207` and a weaker glow. Glow is decoration only: a state or meaning is never carried by the glow alone.
- **Performance:** glows are `box-shadow`, `text-shadow` and radial gradients; transitions animate opacity and `box-shadow` only (never blur radius), and the only looping animations are the green radar dot and the star canvas. All glow transitions are off under `prefers-reduced-motion`.

## 7. Non-Functional Requirements **[Proposed]**

| Area | Requirement |
| --- | --- |
| Performance | Lighthouse Performance ≥ 90 on mobile; no large unoptimized images |
| Accessibility | Lighthouse Accessibility ≥ 90; semantic HTML (`header`, `main`, `section`, `footer`); text contrast ≥ 4.5:1; visible focus states; keyboard-navigable |
| Responsive | Works from 320px up to large desktop |
| SEO | Page `<title>`, meta description, Open Graph tags |
| Browser support | Latest Chrome, Edge, Firefox, Safari |
| Motion | Scroll-reveal, hover and smooth-scroll animations with CSS and `IntersectionObserver` (no animation library); respect `prefers-reduced-motion` |

## 8. Technical Requirements **[Decided]**

- **Build tool:** Vite
- **Library:** React with plain JavaScript (no TypeScript at first)
- **Styling:** plain CSS (or CSS Modules)
- **Hosting:** Vercel free tier, connected to a GitHub repository (auto-deploy on `git push`)
- **Language:** English only
- **Icons:** `react-icons` **[Proposed]**

### Suggested structure

```
src/
├─ components/ (Navbar, ThemeToggle, Hero, About, Skills, Projects, Contact, Footer)
├─ data/       (projects.js, skills.js)
├─ hooks/      (useTheme.js, useReveal.js)
├─ styles/     (variables.css, global.css)
├─ App.jsx
└─ main.jsx
```

### Data shape

```js
// projects.js
{ title, description, tech: [], demo, github }

// skills.js
{ group, items: [{ name, note, icon }] }
```

## 9. Acceptance Criteria

1. All five sections render in order with the agreed content and the agreed color palette.
2. Every nav link and button scrolls or opens to the correct destination.
3. The site has no layout break and no horizontal scroll at 320px, 768px and 1280px.
4. Adding a project to `projects.js` shows a new card without editing any component.
5. Missing demo/GitHub links never produce a broken button.
6. The site is live on a public Vercel URL and updates after a `git push`.
7. Lighthouse scores meet the targets in section 7.
8. The theme toggle switches between light and dark, the choice is remembered, and there is no flash of the wrong theme on reload.
9. In light mode the background is a warm, slightly yellowish white, and all text stays readable.
10. Sections and skill items animate in on scroll, and no animation runs when reduced motion is enabled.
11. Every skill shows an icon, a name and a note, neatly aligned on phone and desktop.
12. Text sizes, weights, fonts and colors follow the Typography table in section 6.1, with the navbar at 13.5px or more and the headline gradient as the documented exceptions.
13. The dock navbar is fully rounded, blurs its background, and switches to the stronger glass look after scrolling down.
14. The logo shows `Kareem` with a pulsing green dot, and the hero badge shows the radar dot with the availability text.
15. The About section renders as a Bento grid of glass cards, one column on phones.
16. The Experience timeline renders from `experience.js` with glowing nodes, `▹` bullets, period badges and tech tags (or is hidden when empty).
17. The star canvas shows 300+ colored stars with mouse parallax and slow drift, and stops moving with reduced motion; scrolling stays smooth on a mid-range phone.
18. The yellow glow follows the table in section 6.2: 2 or 3 glowing yellow elements per screen at most, one shared recipe, yellow focus ring, weaker and readable in light mode.
19. The logo reads `Kareem` with no `<`, `/` or `>` characters.

## 10. Success Metrics **[Proposed]**

- The site is live and shareable.
- Kareem can add a project in under 5 minutes.
- Lighthouse Performance and Accessibility both at 90 or above.
- The link is used in job applications and on GitHub profile.

## 11. Milestones **[Proposed]**

| # | Milestone | Output |
| --- | --- | --- |
| 1 | Project setup | Vite + React project, global CSS variables, folder structure |
| 2 | Layout & sections | Glass dock navbar with theme toggle, Hero, Bento About, Experience timeline, Skills (with icons), Contact, star background |
| 3 | Polish | Light/dark palettes, scroll animations, responsive pass, glow background, hover states, accessibility check |
| 4 | Deploy | GitHub repo + Vercel, live URL |
| 5 | Projects | Add the 3 projects to `projects.js` and redeploy |

## 12. Risks & Dependencies

| Risk / dependency | Impact | Mitigation |
| --- | --- | --- |
| Only 3 projects, and none added at launch | Projects section looks empty at first | Build the section with the data file; fill it in milestone 5 |
| No LinkedIn account | Recruiters often search there first | Create a basic profile and add the link later |
| No CV yet | Some recruiters expect one | Add the button when an English CV is ready |
| Skill notes not written | Skills rows look bare | Kareem writes one honest line per skill before launch |
| Colors are estimated from a screenshot | Slight difference from the reference | Adjust the CSS variables once after review |
| Font families cannot be read from an image | Letter shapes may differ slightly from the reference | Use the closest Google Fonts, then swap `--font-*` if the real names are found in DevTools |
| The reference site's animation could not be inspected | Result may differ from what Kareem saw | Build standard scroll-reveal, then adjust after Kareem reviews it |
| Light mode colors are a first guess | Yellow or teal may be hard to read on cream | Check contrast and tune `--yellow-text` and `--accent` for light mode |
| Animated star canvas plus heavy blur effects | Jank or battery drain on phones; Lighthouse Performance may drop | Fewer stars on small screens, pause when hidden, cap pixel ratio, measure with Lighthouse and cut the extras if needed |
| Hero chips list skills not in the agreed list | A recruiter may ask about TypeScript, Node.js or REST APIs in an interview | Keep only the skills Kareem actually has |
| No real Experience entries yet | An empty or invented timeline hurts credibility | Hide the section until real entries exist; never ship placeholders |
| Too much yellow glow | Looks gaudy, hurts readability and contrast | One shared recipe, 2 or 3 glows per screen, weaker in light mode, check contrast |

## 13. Open Questions

1. The one-line note for each skill (to be written by Kareem).
2. Final email address to display.
3. GitHub profile URL.
4. Whether to buy a custom domain later.
5. Exact wording of the Hero tagline and badge, if Kareem wants changes.
6. Which of the 3 projects use React, and their demo/GitHub links (needed for milestone 5).
7. What exactly the reference site's Experience animation does (fade, slide, line drawing, something else), so it can be matched.
8. Whether the light-mode cream shade feels right (adjustable through `--bg` and `--glow`).
9. Which tech chips are accurate (TypeScript, Node.js, REST APIs are not in the agreed skills list).
10. The real Experience entries: title, organization, period, achievements and technologies.
11. The value for the Experience stat card in the Hero.
12. Whether the star canvas should show in light mode, and in what style.
13. Whether Skills should also appear in the navbar (the spec lists Home, About, Experience, Projects, Contact).
