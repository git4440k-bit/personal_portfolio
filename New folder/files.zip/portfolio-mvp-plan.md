# MVP Plan — Kareem Mahmoud Portfolio

Based on `portfolio-plan.md` and `portfolio-prd.md`.
Items marked **[Proposed]** are my suggestions and can be changed.

---

## 1. MVP Definition

**The MVP is the smallest version that is live on a public URL and that a recruiter can open on a phone and understand in 30 seconds:** who Kareem is, what he does, which skills he has, and how to contact him.

> **MVP = Glass dock navbar + Hero + About (Bento) + Skills + Contact + star background, deployed on Vercel. Experience is included once Kareem provides real entries.**

Success test: Kareem can put the link in a job application today.

## 2. Scope

| Priority | Feature | In MVP? |
| --- | --- | --- |
| Must | Vite + React project, CSS variables, light and dark themes (warm cream white in light mode) with static glow | Yes |
| Must | Floating glass dock navbar (blur, stronger glass on scroll, `Kareem` logo with live dot, Connect button), smooth scroll, mobile menu and light/dark toggle | Yes |
| Must | Hero (availability radar badge, gradient headline, identity line, tech chips, 2 CTAs, stat cards) | Yes |
| Must | About as a Bento grid of glass cards (approved text inside) | Yes |
| Must | Experience timeline (`Experience.jsx`, `Experience.css`, `experience.js`) | Yes, when real entries exist; otherwise hidden **[Proposed]** |
| Must | 360 degree star background (`StarBackground.jsx`) with reduced-motion and mobile safeguards | Yes |
| Must | Glowing yellow accent system (shared glow tokens, applied at the planned focal points) | Yes |
| Must | Skills (3 groups, neat layout, an icon + name + one-line note per skill) | Yes |
| Must | Scroll-reveal animations like the reference site (reduced-motion safe) | Yes |
| Must | Contact (Email + GitHub) | Yes |
| Must | Responsive down to 320px | Yes |
| Must | Deploy on Vercel from GitHub | Yes |
| Should | Projects section built from `projects.js` | Yes, structure only **[Proposed]** (see section 5) |
| Should | Basic SEO (title, meta description, Open Graph) | Yes |
| Could | Footer | Yes, it is tiny |
| Won't (now) | The 3 real projects, LinkedIn link, CV button, custom domain, blog, Arabic | Later |

## 3. Build Order

Rough effort estimates, assuming Kareem is comfortable with React basics. They are guesses, not commitments.

### Step 1 — Setup (about 1 to 2 hours)
- [ ] `npm create vite@latest portfolio -- --template react`
- [ ] Create folders: `components/`, `data/`, `styles/`
- [ ] Add `variables.css` with the dark and light palettes **and the font and size tokens from `portfolio-plan.md` section 4 (Typography)**, and `global.css` (reset, fonts, background glow)
- [ ] Load the Google Fonts (Inter Tight, Inter, JetBrains Mono) with `display=swap`
- [ ] Add the yellow glow tokens (`--yellow-glow`, `--yellow-glow-soft`, `--glow-yellow`, `--glow-yellow-text`) to `variables.css`, with the weaker light-mode values
- [ ] Add the small theme script in `index.html` (applies `data-theme` before first paint)
- [ ] Create a GitHub repo and push the first commit

**Done when:** `npm run dev` shows the glow background, and changing `data-theme` in the browser switches dark and light.

### Step 2 — Navbar + Hero (about 3 to 4 hours)
- [ ] Floating glass dock navbar: fully rounded, `blur(20px)`, switching to `blur(28px) saturate(200%)` after scrolling; links Home, About, Experience, Projects, Contact at 13.5px or more, plus the Connect button
- [ ] Logo as the plain word `Kareem` (no `<`, `/`, `>`) with the green radar-pulse dot
- [ ] Smooth scroll to sections
- [ ] Mobile menu (open/close)
- [ ] Theme toggle (`useTheme` hook, saved in `localStorage`, defaults to the device setting)
- [ ] Hero: live availability badge, gradient headline "Building scalable web experiences", identity line with "Front-end" in yellow, tech chips, `Explore Projects ↗` and `Get in Touch`, stat cards
- [ ] Style the Hero text exactly as in the Typography table (112px two-line name, 32px subtitle, mono label line, 18px gray paragraph, pill buttons)

**Done when:** the top of the page looks right on phone and desktop, and the buttons scroll to the right sections.

### Step 3 — About + Skills (about 3 to 4 hours)
- [ ] About as a Bento grid of glass cards with a subtle 3D tilt (approved text in the Bio card)
- [ ] `skills.js` with the 3 groups and an icon for each skill (`react-icons`)
- [ ] Skills layout in the style of the reference site's Experience section: group heading, then neat items with icon, name and note
- [ ] `experience.js` with the real entries from Kareem, then `Experience.jsx` and `Experience.css`: glowing gradient line, glowing hover nodes, cards with period badge, `▹` achievements and tech tags; wire it into `App.jsx` (hide it if there are no entries)

**Done when:** Skills render from the data file and every skill has a real one-line note.

### Step 4 — Contact + Footer (about 1 hour)
- [ ] Email (`mailto:`) and GitHub links
- [ ] Footer with name and year

**Done when:** both links open the right place.

### Step 5 — Projects structure (about 1 to 2 hours) **[Proposed]**
- [ ] `projects.js` with the agreed data shape
- [ ] `Projects.jsx` rendering cards, hiding missing demo/GitHub buttons

**Done when:** adding one object to the array shows a new card.

### Step 6 — Animations (about 2 to 3 hours)
- [ ] `useReveal` hook with `IntersectionObserver` (fade/slide up when a section or item enters the screen)
- [ ] Staggered reveal for skill items and project cards
- [ ] Hover effects (lift, glow) on skill items, cards and buttons; active nav link while scrolling
- [ ] Turn off all motion when `prefers-reduced-motion` is enabled
- [ ] `StarBackground.jsx`: fixed canvas with `perspective: 1100px` projection, mouse rotation with damping, slow ambient drift, 300+ stars in four colors plus shooting stars; pause when the tab is hidden, fewer stars on phones, static with reduced motion

**Done when:** scrolling the page animates sections in smoothly, and nothing animates with reduced motion on.

### Step 7 — Polish & check (about 2 hours)
- [ ] Test at 320px, 768px and 1280px, with no horizontal scroll, in both light and dark themes
- [ ] Hover and focus states, text contrast
- [ ] Check the yellow glow: 2 or 3 glowing yellow elements per screen at most, yellow focus ring, readable and subtler in light mode
- [ ] Page `<title>`, meta description, Open Graph tags
- [ ] Run Lighthouse (target: 90+ Performance and Accessibility)

### Step 8 — Deploy (about 30 minutes)
- [ ] Import the repo into Vercel and deploy
- [ ] Open the live link on a real phone

**Total estimate: roughly 24 to 34 hours of work.** The Bento grid, Experience timeline and star canvas add about 10 to 14 hours to the earlier estimate; this is a guess, not a commitment.

## 4. What Kareem Needs To Prepare Before Step 3

1. One honest line for each skill (HTML5, CSS3, JavaScript, React, Git/GitHub, Responsive Design, Vite).
   Also confirm which Hero chips are true (TypeScript, Node.js and REST APIs are not in the agreed list), and send the real Experience entries.
2. The email address to display.
3. The GitHub profile URL.

## 5. The Projects Question **[Proposed]**

A portfolio with an empty Projects section looks weak, but the plan says the 3 projects are added after the site is finished. Two options for launch day:

| Option | What visitors see | Trade-off |
| --- | --- | --- |
| **A. Hide the Projects section and its nav link until the first project is ready** | A clean 4-section site | Less to show, but nothing looks unfinished |
| **B. Show the section with a short "Projects coming soon" message** | A visible placeholder | Honest, but a placeholder is the first thing a recruiter may notice |

Recommendation: **Option A**, and add the first project as soon as possible (this is the first item after the MVP).

## 6. Definition of Done (MVP)

1. The site is live on a public Vercel URL.
2. Navbar, Hero, About, Skills and Contact show the agreed content and palettes (dark, and light with a warm yellowish white).
3. No layout break or horizontal scroll at 320px, 768px and 1280px, in both themes.
4. The theme toggle works, is remembered, and does not flash on reload.
5. Sections and skill items animate in on scroll, and every skill has an icon.
6. Email and GitHub links work.
7. Every skill has a real note, and no placeholder text is left.
8. Lighthouse Performance and Accessibility are 90 or above on mobile.
9. A `git push` updates the live site.

## 7. After the MVP (in order)

| # | Item | Why |
| --- | --- | --- |
| 1 | Add the 3 real projects with demo and GitHub links | The most important proof for a front-end role |
| 2 | Create a LinkedIn profile and add the link | Recruiters search there first |
| 3 | Prepare an English CV and add a download button | Many applications ask for one |
| 4 | Custom domain (for example `kareemmahmoud.dev`) | Looks more professional |
| 5 | Optional extras: Arabic version, TypeScript | Nice to have |

## 8. If Time Runs Short

Cut in this order and still ship:
1. Star canvas extras (shooting stars, extra depth layers; fall back to a static glow if performance is poor)
2. Footer
3. Staggered and hover animation extras (keep a simple fade-in)
4. Bento card tilt and the yellow background halos (keep flat glass cards, and keep the glowing underline, timeline line and nodes)
5. Open Graph tags
6. Mobile menu animation (keep a simple one)
7. Projects structure (use Option A and add it later)

Never cut: responsiveness, readable contrast in both themes, the light/dark toggle, working contact links, deployment.
